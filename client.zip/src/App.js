// src/App.js
import './App.css';
import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

import Ventas from './components/Ventas';
import Productos from './components/Productos';
import Clientes from './components/Clientes';
import Reportes from './components/Reportes';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [productos, setProductos] = useState([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isLoggedIn) {
      setIsLoading(true);
      fetch('http://localhost:5000/api/productos')
        .then(res => res.json())
        .then(data => setProductos(data))
        .catch(err => console.error('Error al obtener productos:', err))
        .finally(() => setIsLoading(false));
    }
  }, [isLoggedIn]);

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  if (!isLoggedIn) {
    return <Login onLogin={() => setIsLoggedIn(true)} />;
  }

  return (
    <Router>
      <div className="flex min-h-screen bg-gray-100">
        {/* Sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-50 w-64 bg-gray-800 text-white transform ${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } md:translate-x-0 md:static md:w-64 p-6 transition-transform duration-300 ease-in-out shadow-lg`}
        >
          <div className="flex items-center justify-between mb-8">
            <div className="text-3xl font-bold text-yellow-400">Botica</div>
            <button
              className="md:hidden text-white text-2xl focus:outline-none"
              onClick={() => setIsSidebarOpen(false)}
              aria-label="Close sidebar"
            >
              ✕
            </button>
          </div>
          <ul className="space-y-2">
            <li>
              <Link
                to="/"
                className="block text-lg px-4 py-2 rounded-lg hover:bg-purple-600 transition-all duration-300"
                onClick={() => setIsSidebarOpen(false)}
              >
                Principal
              </Link>
            </li>
            <li>
              <Link
                to="/ventas"
                className="block text-lg px-4 py-2 rounded-lg hover:bg-purple-600 transition-all duration-300"
                onClick={() => setIsSidebarOpen(false)}
              >
                Ventas
              </Link>
            </li>
            <li>
              <Link
                to="/productos"
                className="block text-lg px-4 py-2 rounded-lg hover:bg-purple-600 transition-all duration-300"
                onClick={() => setIsSidebarOpen(false)}
              >
                Productos
              </Link>
            </li>
            <li>
              <Link
                to="/clientes"
                className="block text-lg px-4 py-2 rounded-lg hover:bg-purple-600 transition-all duration-300"
                onClick={() => setIsSidebarOpen(false)}
              >
                Clientes
              </Link>
            </li>
            <li>
              <Link
                to="/reportes"
                className="block text-lg px-4 py-2 rounded-lg hover:bg-purple-600 transition-all duration-300"
                onClick={() => setIsSidebarOpen(false)}
              >
                Reportes
              </Link>
            </li>
          </ul>
        </aside>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <header className="bg-white shadow-md p-4 flex justify-between items-center">
            <button
              className="md:hidden text-gray-800 text-2xl focus:outline-none"
              onClick={() => setIsSidebarOpen(true)}
              aria-label="Open sidebar"
            >
              ☰
            </button>
            <h1 className="text-2xl font-bold text-gray-800">Bienvenido, Administrador</h1>
            <button
              onClick={handleLogout}
              className="text-red-500 hover:text-red-700 transition-colors duration-200"
            >
              Cerrar Sesión
            </button>
          </header>

          {/* Content */}
          <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-auto bg-gray-100">
            <div className="max-w-6xl mx-auto bg-white rounded-lg shadow-md p-6">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin h-8 w-8 border-4 border-t-transparent border-purple-600 rounded-full" />
                </div>
              ) : (
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/ventas" element={<Ventas />} />
                  <Route path="/productos" element={<Productos productos={productos} setProductos={setProductos} />} />


                  <Route path="/clientes" element={<Clientes />} />
                  <Route path="/reportes" element={<Reportes />} />
                </Routes>
              )}
            </div>
          </main>
        </div>
      </div>
    </Router>
  );
}

export default App;