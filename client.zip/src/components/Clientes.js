import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Cliente = () => {
  // Estado para almacenar los datos de los clientes
  const [clientes, setClientes] = useState([]);
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [telefono, setTelefono] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [selectedClienteId, setSelectedClienteId] = useState(null);

  // Obtener los clientes al cargar el componente
  useEffect(() => {
    fetchClientes();
  }, []);

  const fetchClientes = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/clientes');
      setClientes(response.data);
    } catch (error) {
      console.error('Error al obtener los clientes:', error);
    }
  };

  // Manejar la creación de un nuevo cliente
  const handleCreateCliente = async () => {
    if (!nombre || !email || !telefono) {
      alert('Por favor, completa todos los campos');
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/api/clientes', {
        nombre,
        email,
        telefono,
      });

      if (response.data.success) {
        alert('Cliente agregado con éxito');
        fetchClientes();
        setNombre('');
        setEmail('');
        setTelefono('');
      }
    } catch (error) {
      console.error('Error al agregar el cliente:', error);
    }
  };

  // Manejar la edición de un cliente
  const handleEditCliente = (cliente) => {
    setEditMode(true);
    setSelectedClienteId(cliente.id);
    setNombre(cliente.nombre);
    setEmail(cliente.email);
    setTelefono(cliente.telefono);
  };

  // Manejar la actualización de un cliente
  const handleUpdateCliente = async () => {
    if (!nombre || !email || !telefono) {
      alert('Por favor, completa todos los campos');
      return;
    }

    try {
      const response = await axios.put(
        `http://localhost:5000/api/clientes/${selectedClienteId}`,
        {
          nombre,
          email,
          telefono,
        }
      );

      if (response.data.success) {
        alert('Cliente actualizado con éxito');
        fetchClientes();
        setEditMode(false);
        setNombre('');
        setEmail('');
        setTelefono('');
        setSelectedClienteId(null);
      }
    } catch (error) {
      console.error('Error al actualizar el cliente:', error);
    }
  };

  // Manejar la eliminación de un cliente
  const handleDeleteCliente = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:5000/api/clientes/${id}`);

      if (response.data.success) {
        alert('Cliente eliminado con éxito');
        fetchClientes();
      }
    } catch (error) {
      console.error('Error al eliminar el cliente:', error);
    }
  };

  return (
    <div>
      <h1>{editMode ? 'Editar Cliente' : 'Agregar Cliente'}</h1>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (editMode) {
            handleUpdateCliente();
          } else {
            handleCreateCliente();
          }
        }}
      >
        <div>
          <label>Nombre:</label>
          <input
            type="text"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label>Teléfono:</label>
          <input
            type="text"
            value={telefono}
            onChange={(e) => setTelefono(e.target.value)}
          />
        </div>
        <button type="submit">{editMode ? 'Actualizar Cliente' : 'Agregar Cliente'}</button>
      </form>

      <h2>Clientes</h2>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {clientes.map((cliente) => (
            <tr key={cliente.id}>
              <td>{cliente.nombre}</td>
              <td>{cliente.email}</td>
              <td>{cliente.telefono}</td>
              <td>
                <button onClick={() => handleEditCliente(cliente)}>Editar</button>
                <button onClick={() => handleDeleteCliente(cliente.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Cliente;
