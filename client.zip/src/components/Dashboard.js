// src/components/Dashboard.js
import React from 'react';

const Dashboard = () => {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="bg-white p-10 rounded-2xl shadow-md text-center w-full max-w-2xl">
        <h2 className="text-3xl font-bold text-blue-600 mb-4">Bienvenido al Dashboard</h2>
        <p className="text-gray-600">Aquí puedes administrar tus ventas, productos, clientes y reportes.</p>
      </div>
    </div>
  );
};

export default Dashboard;
