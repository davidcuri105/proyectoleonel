// client/src/components/Login.js
import React, { useState } from 'react';

function Login({ onLogin }) {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    fetch('http://localhost:5000/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user, password }),
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          onLogin();
        } else {
          setError('Usuario o contraseña incorrectos');
        }
      })
      .catch(err => {
        console.error('Error en login:', err);
        setError('Error al iniciar sesión');
      })
      .finally(() => setIsLoading(false));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-indigo-500 to-pink-500 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl p-8 transform hover:-rotate-2 transition-transform duration-300">
        <h2 className="text-3xl font-extrabold text-center text-yellow-400 mb-6 animate-pulse">
          ¡Bienvenido!
        </h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative">
            <label
              htmlFor="user"
              className="absolute -top-2 left-3 bg-white px-1 text-sm font-semibold text-purple-600 transition-all duration-200"
            >
              Usuario
            </label>
            <input
              id="user"
              type="text"
              placeholder="Tu usuario"
              value={user}
              onChange={(e) => setUser(e.target.value)}
              required
              className="w-full px-4 py-3 bg-gray-50 border-2 border-purple-300 rounded-xl focus:border-gradient-to-r focus:from-purple-600 focus:to-indigo-500 focus:ring-4 focus:ring-purple-200 outline-none transition-all duration-300 hover:scale-105"
              aria-label="Usuario"
            />
          </div>
          <div className="relative">
            <label
              htmlFor="password"
              className="absolute -top-2 left-3 bg-white px-1 text-sm font-semibold text-purple-600 transition-all duration-200"
            >
              Contraseña
            </label>
            <input
              id="password"
              type="password"
              placeholder="Tu contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-4 py-3 bg-gray-50 border-2 border-purple-300 rounded-xl focus:border-gradient-to-r focus:from-purple-600 focus:to-indigo-500 focus:ring-4 focus:ring-purple-200 outline-none transition-all duration-300 hover:scale-105"
              aria-label="Contraseña"
            />
          </div>
          {error && (
            <div
              className="bg-red-100 text-red-600 text-sm text-center p-2 rounded-md shadow-md animate-slide-in"
              role="alert"
            >
              {error}
            </div>
          )}
          <button
            type="submit"
            disabled={isLoading}
            className={`w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-indigo-500 text-white font-bold rounded-xl hover:scale-110 hover:shadow-lg transition-all duration-300 ${
              isLoading ? 'opacity-70 cursor-not-allowed' : 'animate-bounce-slow'
            }`}
            aria-label="Iniciar sesión"
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <div className="animate-spin h-6 w-6 border-3 border-t-transparent border-yellow-400 rounded-full mr-2"></div>
                Cargando...
              </span>
            ) : (
              '¡Vamos!'
            )}
          </button>
        </form>
      </div>
      <style jsx>{`
        .animate-slide-in {
          animation: slideIn 0.3s ease-out;
        }
        .animate-bounce-slow {
          animation: bounceSlow 2s infinite;
        }
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes bounceSlow {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-5px);
          }
        }
      `}</style>
    </div>
  );
}

export default Login;