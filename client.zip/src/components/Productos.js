import React, { useEffect, useState } from 'react';

function Productos({ productos, setProductos }) {
  const [formData, setFormData] = useState({
    codigo: '',
    nombre: '',
    cantidad: '',
    precio: '',
  });

  const [isEditing, setIsEditing] = useState(false);

  // Cargar productos al montar
  useEffect(() => {
    fetch('http://localhost:5000/api/productos')
      .then((res) => res.json())
      .then((data) => setProductos(data))
      .catch((err) => console.error('Error al cargar productos:', err));
  }, [setProductos]);

  // Manejo de inputs
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Validar formulario
  const validateForm = () => {
    const { codigo, nombre, cantidad, precio } = formData;
    if (!codigo || !nombre || !cantidad || !precio) return 'Todos los campos son requeridos.';
    if (isNaN(cantidad) || cantidad <= 0) return 'La cantidad debe ser un número positivo.';
    if (isNaN(precio) || precio <= 0) return 'El precio debe ser un número positivo.';
    return null;
  };

  // Agregar nuevo producto
  const handleAdd = () => {
    const error = validateForm();
    if (error) return alert(error);

    fetch('http://localhost:5000/api/productos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...formData,
        cantidad: parseInt(formData.cantidad),
        precio: parseFloat(formData.precio),
      }),
    })
      .then((res) => res.json())
      .then(() => refreshData())
      .catch(() => alert('Error al agregar producto'));
  };

  // Guardar cambios al editar
  const handleEditSave = () => {
    const error = validateForm();
    if (error) return alert(error);

    fetch(`http://localhost:5000/api/productos/${formData.codigo}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nombre: formData.nombre,
        cantidad: parseInt(formData.cantidad),
        precio: parseFloat(formData.precio),
      }),
    })
      .then((res) => res.json())
      .then(() => {
        refreshData();
        setIsEditing(false);
      })
      .catch(() => alert('Error al editar producto'));
  };

  // Eliminar producto
  const handleDelete = (codigo) => {
    if (!window.confirm('¿Eliminar este producto?')) return;
    fetch(`http://localhost:5000/api/productos/${codigo}`, {
      method: 'DELETE',
    })
      .then(() => refreshData())
      .catch(() => alert('Error al eliminar producto'));
  };

  // Seleccionar producto para editar
  const handleEditSelect = (codigo) => {
    const producto = productos.find((p) => p.codigo === codigo);
    if (producto) {
      setFormData({
        codigo: producto.codigo,  // Ya no es necesario convertir a String si es un número
        nombre: producto.nombre || '',
        cantidad: producto.cantidad || '',  // Asegúrate de que siempre sea un número
        precio: producto.precio || '',  // Asegúrate de que siempre sea un número
      });
      setIsEditing(true); // Activar el estado de edición
    }
  };

  // Cancelar edición
  const handleCancel = () => {
    setFormData({ codigo: '', nombre: '', cantidad: '', precio: '' });
    setIsEditing(false);
  };

  // Refrescar lista
  const refreshData = () => {
    fetch('http://localhost:5000/api/productos')
      .then((res) => res.json())
      .then((data) => {
        setProductos(data);
        setFormData({ codigo: '', nombre: '', cantidad: '', precio: '' });
      });
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Gestión de Productos</h2>

      {/* Formulario */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <input
          name="codigo"
          placeholder="Código"
          value={formData.codigo}
          onChange={handleChange}
          className="p-2 border border-gray-300 rounded"
          disabled={isEditing} // no editar código durante edición
        />
        <input
          name="nombre"
          placeholder="Nombre"
          value={formData.nombre}
          onChange={handleChange}
          className="p-2 border border-gray-300 rounded"
        />
        <input
          name="cantidad"
          placeholder="Cantidad"
          value={formData.cantidad}
          onChange={handleChange}
          type="number"
          className="p-2 border border-gray-300 rounded"
        />
        <input
          name="precio"
          placeholder="Precio"
          value={formData.precio}
          onChange={handleChange}
          type="number"
          className="p-2 border border-gray-300 rounded"
        />
      </div>

      {/* Botones */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={isEditing ? handleEditSave : handleAdd}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          {isEditing ? 'Guardar Cambios' : 'Agregar Producto'}
        </button>
        {isEditing && (
          <button
            onClick={handleCancel}
            className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
          >
            Cancelar
          </button>
        )}
      </div>

      {/* Tabla */}
      <table className="w-full table-auto shadow border rounded">
        <thead className="bg-gray-100 text-sm text-gray-600">
          <tr>
            <th className="py-2 px-4 text-left">Código</th>
            <th className="py-2 px-4 text-left">Nombre</th>
            <th className="py-2 px-4 text-left">Cantidad</th>
            <th className="py-2 px-4 text-left">Precio</th>
            <th className="py-2 px-4 text-left">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {productos.map((p) => (
            <tr key={p.codigo} className="border-t">
              <td className="py-2 px-4">{p.codigo}</td>
              <td className="py-2 px-4">{p.nombre}</td>
              <td className="py-2 px-4">{p.cantidad}</td>
              <td className="py-2 px-4">${p.precio}</td>
              <td className="py-2 px-4 space-x-2">
                <button
                  onClick={() => handleEditSelect(p.codigo)}
                  className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600"
                >
                  Editar
                </button>
                <button
                  onClick={() => handleDelete(p.codigo)}
                  className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Productos;
