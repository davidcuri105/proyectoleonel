import React from 'react';

function Reportes() {
  return (
    <section className="reports-section">
      <h2>Reportes</h2>
      <p>Aquí se mostrarán los reportes generados...</p>
    </section>
  );
}

export default Reportes;
