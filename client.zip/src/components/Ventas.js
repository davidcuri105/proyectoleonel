import React from 'react';

function Ventas() {
  return (
    <section className="sales-section">
      <h2>Ventas</h2>
      <p>Aquí se mostrará el historial de ventas...</p>
    </section>
  );
}

export default Ventas;
